

int ParseInteger(const char* str, int* value);
int ParseDouble(const char* str, double* value);
int ParsingErrorHelper(int err, const char* msg);
