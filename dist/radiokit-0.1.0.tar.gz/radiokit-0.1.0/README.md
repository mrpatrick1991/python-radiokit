# radio-kit
A Python module for easily running radio propagation simulations and link analysis using digital elevation models.
